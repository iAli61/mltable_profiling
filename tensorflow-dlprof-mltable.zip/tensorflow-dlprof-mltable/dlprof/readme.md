```
 conda create --name dlprof python=3.10
 conda activate dlprof 
 pip install -r requirements.txt 
```
